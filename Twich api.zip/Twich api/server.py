import socket
from flask import Flask,request
import time
import sqlite3
import inspect
import os
from bot import db_name,db_dir
from base32 import b32decode

def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

class API:
    def __init__(self,dbsrc):
        self.app = Flask(__name__)
        self.dbsrc=dbsrc

    def get(self,func):
        def getHandler():
            db = sqlite3.connect(self.dbsrc)
            c = db.cursor()
            args = inspect.getfullargspec(func).args
            dct = {k:request.args.get(k) if k!="db" else c for k in args}
            value=func(**dct)
            db.commit()
            db.close()
            return value
        getHandler.__name__=func.__name__
        self.app.route("/"+func.__name__,methods=["GET"])(getHandler)
        

    def post(self,func):
        def getHandler():
            args = inspect.getfullargspec(func).args
            db = sqlite3.connect(self.dbsrc)
            c = db.cursor()
            dct = {k:request.form[k] if k!="db" else c for k in args}
            value=func(**dct)
            db.commit()
            db.close()
            return value
        getHandler.__name__=func.__name__
        self.app.route("/"+func.__name__,methods=["POST"])(getHandler)
        

    def run(self):
        self.app.run()

TwitchAPI = API(db_dir)

@TwitchAPI.get
def chatlog(db,secondsBackInTime):
    t = time.time()-int(secondsBackInTime)
    db.execute("SELECT * FROM chat WHERE ts > ?",(str(t),))
    records = db.fetchall()
    keys = "ts,user,channel,message".split(",")
    json = {"messages": []}
    for i in records:
        json["messages"]+=[dict_factory(db,i)]
        json["messages"][-1]['message']=b32decode(json["messages"][-1]['message'])
        
    json["numberOfMessages"]=len(json["messages"])
    return repr(json)

@TwitchAPI.get
def index(db):
    with open("index.html","r") as rf:
        return rf.read()

@TwitchAPI.get
def questions_pr_minute(db,,channel):
    db.execute(f"SELECT * FROM chat WHERE channel=?",(channel,))
    records = cursor.fetchall()
    keys = "ts,user,channel,message".split(",")
    d = []
    for i in records:
        d+=[dict_factory(db,i)]
        d[-1]['message']=b32decode(d[-1]['message'])
    d = [i for i in d if "?" in i["message"]]
    tspent = d[-1]["ts"] - d[0]["ts"]
    return repr((len(d)/tspent)/seconds)

@TwitchAPI.post
def track(db,channel):
    os.system("start py bot.py "+channel)
    return repr({
        "timeStarted": time.time(),
        "channel": channel
        })
@TwitchAPI.get
def time_avr(db,seconds,channel):
    db.execute(f"SELECT * FROM chat WHERE channel=?",(channel,))
    records = db.fetchall()
    keys = "ts,user,channel,message".split(",")
    d = []
    for i in records:
        d+=[dict_factory(db,i)]
    tspent = d[-1]["ts"] - d[0]["ts"]
    return repr((len(d)*int(seconds)/tspent))

TwitchAPI.run()


        
