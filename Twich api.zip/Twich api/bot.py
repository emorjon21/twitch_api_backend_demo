import socket
from flask import Flask,request
import time
import sqlite3
import os,sys
import traceback
from base32 import b32encode

client_id           =   ""                              #your client ID
secret              =   ""                              #your secret api key, in case you need it
connection_data     =   ("irc.chat.twitch.tv",6667)     #the port data for the socket lib

token       =       ""                      #your twitch chat oauth password.
username    =       ""                      #your nick name
db_name     =       "chat.db"               #the name of the database file. has to be backed up and then removed before server startup to get clean statistics.
db_dir      =       "data/"+db_name         #the full path of the database file

def twitch_load(channel):
    print("connecting to channel "+channel)
            
    def get_messages(): # a local generator for fetching messages.
        while True:
            #connecting to twitch api using native socket lib and send a request.
            server=socket.socket()
            server.connect(connection_data)
            server.send(bytes("PASS "+token+"\r\n","utf-8"))
            server.send(bytes("NICK "+username+"\r\n","utf-8"))
            server.send(bytes("JOIN #"+channel+"\r\n","utf-8"))
            print("connected to server for channel "+channel)
            while True:

                """fetching the messages as long as this bot is running. Thus this generator will not stop. a for loop just turned into a while loop.
                    The reason for a while loop within a whileloop is because sooner or later the recv function will start
                    returning blank responses. when that happen, the request has to be re-sent."""
                
                message = server.recv(2048).decode("utf-8")
                print("response:"+message)
                if len(message)==0: break #if the response is empty, refresh the request.
                if "PRIVMSG" in message:
                    yield message

    #connecting to the database
    
    conn=sqlite3.connect(db_dir)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS chat(ts int,user text,channel text,message text)")
    conn.commit()
    for i in get_messages(): #start fetching messages live
        user = i.split(":")[1].split("!")[0]
        message = i.split("#"+channel+" :")[-1]
        query=f"INSERT INTO chat VALUES ({time.time()},'{user}','{channel}',\"{b32encode(message)}\")"
        """adds the parsed info to the sqlite database. Reason why message is converted into a base32 string is to avoid special characters to break the query syntax. """
        print(query)
        try:
            c.execute(query)
        except:
            with open(f"error_on_fetching/{time.time()}.txt", "w") as wf:
                wf.write(f"""
on query "{query}:"
{traceback.format_exc()}
""")
        conn.commit()

if __name__=="__main__":
    #twitch_load("zaitr0s")
    twitch_load(sys.argv[1])
