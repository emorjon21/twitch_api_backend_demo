import math
import random
characters = "0123456789abcdefghijklmnopqrstuv"

def int2b32(i):
    dgts = ""
    while True:
        d = int(i%32)
        i-=d
        dgts=characters[d]+dgts
        i=int(i/32)
        if i<1:break
    return dgts

def b32toint(st):
    n=0
    for i in st:
        n*=32
        n+=characters.index(i)
    return n


def b32encode(st):
    st=st.encode("utf-8")
    s=""
    for c in st:
        token = int2b32(c)
        while len(token)<8:token="0"+token
        s+=token
    return s

def b32decode(st):
    bt = bytearray()
    for x in range(0,len(st),8):
        section = b32toint(st[x:x+8])
        bt.append(section)
    return bt.decode("utf-8")


for i in range(100):
    assert b32toint(int2b32(i))==i 

teststring = "Hello World! My Name is Morgan!"
assert b32decode(b32encode(teststring))==teststring

